A python library that allows you to get the fractional part of a number

========================================================================

